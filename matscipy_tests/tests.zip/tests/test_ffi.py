"""Testing that the compiled extension can be imported."""

def test_ffi():
    import matscipy.ffi


if __name__ == "__main__":
    test_ffi()
