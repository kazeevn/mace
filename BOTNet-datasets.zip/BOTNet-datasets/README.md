# BOTNet-datasets

This repo contains the datasets used for the paper The Design Space of E(3)-Equivariant Atom-Centered Interatomic Potentials.

If you use them please cite https://arxiv.org/abs/2205.06643 
