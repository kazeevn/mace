"""
Calculation of continuum linear elastic displacement fields near crack tips,
including support for anisotropy in the elastic response.
"""
